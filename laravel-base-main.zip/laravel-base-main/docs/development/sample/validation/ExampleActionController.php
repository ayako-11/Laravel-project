<?php

class ExampleActionController
{
    public function __invoke(ExampleValidationRequest $request)
    {

    }
}
